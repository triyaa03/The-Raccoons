package com.example.whatnumberamithinkingof;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Hard extends AppCompatActivity {
    Button playAgainButton;
    HardModel A = new HardModel();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hard);
        playAgainButton = findViewById(R.id.playAgainHard);
    }

    public void HardClicked(View v) {
        EditText input = (EditText) findViewById(R.id.inputBox2);
        String inputA = input.getText().toString();

        int userGuess = Integer.parseInt(inputA);
        A.answerHard(userGuess);
        ((TextView) findViewById(R.id.answer2)).setText(A.getMsg());
        if(A.isGameOver() == true){
            playAgainButton.setVisibility(View.VISIBLE);
        }
    }
    public void playAgainClicked(View v){
        A = new HardModel();
        ((TextView) findViewById(R.id.answer2)).setText("New Game");
        playAgainButton.setVisibility(View.INVISIBLE);
    }


}