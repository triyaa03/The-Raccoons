package com.example.whatnumberamithinkingof;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class GoodLuck extends AppCompatActivity {
    Button playAgainButt;
    GoodLuckModel A = new GoodLuckModel();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_good_luck);
        playAgainButt = findViewById(R.id.playAgainGL);
    }

    public void GoodLuckClicked(View v) {
        EditText input = (EditText) findViewById(R.id.inputBox3);
        String inputA = input.getText().toString();

        int userGuess = Integer.parseInt(inputA);
        A.answerGoodLuck(userGuess);
        ((TextView) findViewById(R.id.answer3)).setText(A.getMsg());
        if(A.isGameOver() == true){
            playAgainButt.setVisibility(View.VISIBLE);
        }
    }
    public void playAgainClicked(View v){
        A = new GoodLuckModel();
        ((TextView) findViewById(R.id.answer3)).setText("New Game");
        playAgainButt.setVisibility(View.INVISIBLE);
    }
}