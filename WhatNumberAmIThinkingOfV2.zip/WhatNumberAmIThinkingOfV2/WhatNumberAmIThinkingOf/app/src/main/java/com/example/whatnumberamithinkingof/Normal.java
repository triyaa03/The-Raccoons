package com.example.whatnumberamithinkingof;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class Normal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_normal);
    }

    public void NormalClicked(View v) {
        EditText input = (EditText) findViewById(R.id.inputBox);
        String inputA = input.getText().toString();

        int userGuess = Integer.parseInt(inputA);
        if(userGuess < 1 || userGuess > 10) {
            ((TextView)findViewById(R.id.answer)).setText("Make sure to guess from 1-10");
        }


        String text = "";
        Random randNum = new Random();
        int ans = randNum.nextInt(10)+1;

1

        ((TextView)findViewById(R.id.answer)).setText(A.getMsg());
        }

    }



}