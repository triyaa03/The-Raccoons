package com.example.whatnumberamithinkingof;

import org.junit.Test;
import static org.junit.Assert.*;

public class GoodLuckTest {
    @Test
    public void answerHardTestMsg(){
        int randNum = 3;
        GoodLuckModel A = new GoodLuckModel(randNum);
        A.answerGoodLuck(3);
        assertEquals("You guessed the right number in the first try!", A.getMsg());
    }
    @Test
    public void answerHardTestMsg2(){
        int randNum = 2;
        GoodLuckModel A = new GoodLuckModel(randNum);
        for(int i = 0; i < 3; i++){

            A.answerGoodLuck(i);
        }
        assertEquals("You guessed the right number in 3 tries!", A.getMsg());
    }
    @Test
    public void answerHardTestHintE(){
        int randNum = 6;
        GoodLuckModel A = new GoodLuckModel(randNum);
        A.answerGoodLuck(3);
        assertEquals("The secret number is an even number!", A.getHint());
    }
    @Test
    public void answerHardTestHintO(){
        int randNum = 7;
        GoodLuckModel A = new GoodLuckModel(randNum);
        A.answerGoodLuck(3);
        String msg = A.getHint();
        assertEquals("The secret number is an odd number!", A.getHint());
    }
    @Test
    public void answerHardTestHigh(){
        int randNum = 6;
        GoodLuckModel A = new GoodLuckModel(randNum);
        A.answerGoodLuck(9);
        String msg = A.getMsg();
        assertEquals("Your guess is too high!", A.getMsg());
    }
    @Test
    public void answerHardTestLow(){
        int randNum = 6;
        GoodLuckModel A = new GoodLuckModel(randNum);
        A.answerGoodLuck(3);
        String msg = A.getMsg();
        assertEquals("Your guess is too low!", A.getMsg());
    }
    @Test
    public void answerHardTestMaxTries(){
        int randNum = 6;
        GoodLuckModel A = new GoodLuckModel(randNum);
        for(int i = 0; i < 5; i++){
            A.answerGoodLuck(3);
        }
        assertEquals("The game is over, you lose!", A.getMsg());
    }
    @Test
    public void answerHardTestisGameOver(){
        int randNum = 6;
        GoodLuckModel A = new GoodLuckModel(randNum);
        for(int i = 0; i < 5; i++){
            A.answerGoodLuck(3);
        }
        assertEquals(true, A.isGameOver());
    }
    @Test
    public void answerHardTestisGameOverF(){
        int randNum = 6;
        GoodLuckModel A = new GoodLuckModel(randNum);
        for(int i = 0; i < 4; i++){
            A.answerGoodLuck(3);
        }
        assertEquals(false, A.isGameOver());
    }
}
