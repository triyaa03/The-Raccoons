package com.example.whatnumberamithinkingof;

import org.junit.Test;
import static org.junit.Assert.*;

public class NormalTest {
    @Test
    public void answerNormalTestMsg(){
        int randNum = 3;
        NormalModel A = new NormalModel(randNum);
        A.answerNormal(3);
        String msg = A.getMsg();
        assertEquals("You guessed the right number in the first try!", A.getMsg());
    }
    @Test
    public void answerNormalTestMsg2(){
        int randNum = 2;
        NormalModel A = new NormalModel(randNum);
        for(int i = 0; i < 3; i++){
            A.answerNormal(i);
        }
        String msg = A.getMsg();
        assertEquals("You guessed the right number in 3 tries!", A.getMsg());
    }
    @Test
    public void answerNormalTestHintE(){
        int randNum = 6;
        NormalModel A = new NormalModel(randNum);
        A.answerNormal(3);
        String msg = A.getHint();
        assertEquals("The secret number is an even number!", A.getHint());
    }
    @Test
    public void answerNormalTestHintO(){
        int randNum = 7;
        NormalModel A = new NormalModel(randNum);
        A.answerNormal(3);
        String msg = A.getHint();
        assertEquals("The secret number is an odd number!", A.getHint());
    }
    @Test
    public void answerNormalTestHigh(){
        int randNum = 6;
        NormalModel A = new NormalModel(randNum);
        A.answerNormal(9);
        String msg = A.getMsg();
        assertEquals("Your guess is too high!", A.getMsg());
    }
    @Test
    public void answerNormalTestLow(){
        int randNum = 6;
        NormalModel A = new NormalModel(randNum);
        A.answerNormal(3);
        String msg = A.getMsg();
        assertEquals("Your guess is too low!", A.getMsg());
    }
    @Test
    public void answerNormalTestMaxTries(){
        int randNum = 6;
        NormalModel A = new NormalModel(randNum);
        for(int i = 0; i < 5; i++){
            A.answerNormal(3);
        }
        assertEquals("The game is over, you lose!", A.getMsg());
    }
    @Test
    public void answerNormalTestisGameOver(){
        int randNum = 6;
        NormalModel A = new NormalModel(randNum);
        for(int i = 0; i < 5; i++){
            A.answerNormal(3);
        }
        assertEquals(true, A.isGameOver());
    }
    @Test
    public void answerNormalTestisGameOverF(){
        int randNum = 6;
        NormalModel A = new NormalModel(randNum);
        for(int i = 0; i < 4; i++){
            A.answerNormal(3);
        }
        assertEquals(false, A.isGameOver());
    }
}
