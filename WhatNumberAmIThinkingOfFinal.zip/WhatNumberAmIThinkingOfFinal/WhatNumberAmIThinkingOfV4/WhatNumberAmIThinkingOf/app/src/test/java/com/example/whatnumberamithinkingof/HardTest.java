package com.example.whatnumberamithinkingof;

import org.junit.Test;
import static org.junit.Assert.*;

public class HardTest {
    @Test
    public void answerHardTestMsg(){
        int randNum = 3;
        HardModel A = new HardModel(randNum);
        A.answerHard(3);
        assertEquals("You guessed the right number in the first try!", A.getMsg());
    }
    @Test
    public void answerHardTestMsg2(){
        int randNum = 2;
        HardModel A = new HardModel(randNum);
        for(int i = 0; i < 3; i++){

            A.answerHard(i);
        }
        assertEquals("You guessed the right number in 3 tries!", A.getMsg());
    }
    @Test
    public void answerHardTestHintE(){
        int randNum = 6;
        HardModel A = new HardModel(randNum);
        A.answerHard(3);
        assertEquals("The secret number is an even number!", A.getHint());
    }
    @Test
    public void answerHardTestHintO(){
        int randNum = 7;
        HardModel A = new HardModel(randNum);
        A.answerHard(3);
        String msg = A.getHint();
        assertEquals("The secret number is an odd number!", A.getHint());
    }
    @Test
    public void answerHardTestHigh(){
        int randNum = 6;
        HardModel A = new HardModel(randNum);
        A.answerHard(9);
        String msg = A.getMsg();
        assertEquals("Your guess is too high!", A.getMsg());
    }
    @Test
    public void answerHardTestLow(){
        int randNum = 6;
        HardModel A = new HardModel(randNum);
        A.answerHard(3);
        String msg = A.getMsg();
        assertEquals("Your guess is too low!", A.getMsg());
    }
    @Test
    public void answerHardTestMaxTries(){
        int randNum = 6;
        HardModel A = new HardModel(randNum);
        for(int i = 0; i < 5; i++){
            A.answerHard(3);
        }
        assertEquals("The game is over, you lose!", A.getMsg());
    }
    @Test
    public void answerHardTestisGameOver(){
        int randNum = 6;
        HardModel A = new HardModel(randNum);
        for(int i = 0; i < 5; i++){
            A.answerHard(3);
        }
        assertEquals(true, A.isGameOver());
    }
    @Test
    public void answerHardTestisGameOverF(){
        int randNum = 6;
        HardModel A = new HardModel(randNum);
        for(int i = 0; i < 4; i++){
            A.answerHard(3);
        }
        assertEquals(false, A.isGameOver());
    }
}

